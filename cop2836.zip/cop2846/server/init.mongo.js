db.issues.remove({});

const issuesDB = [
  {
    id: 1, author: 'Stephen Kings',
    created: new Date('2019-01-15'),
    title: 'Carrie', review: 'Good horror story. R.I.P Carrie :(', genre: 'Horror', published: '1974', rating: '5',
    username: 'RoyalReader1',
  },
  {
    id: 2, author: 'H.P. Lovecraft',
    created: new Date('2019-01-16'),
    title: 'The Call of Cthulu', review: 'Very Scary! I enjoyed the cosmic horror story.', genre: 'Horror', published: '1926', rating: '5',
    username: 'RoyalReader1',
  },
];

db.issues.insertMany(issuesDB);
const count = db.issues.count();
print('Inserted', count, 'issues');

db.counters.remove({ _id: 'issues' });
db.counters.insert({ _id: 'issues', current: count });

db.counters.remove({_id: 'issues'});
db.counters.insert({_id: 'issues', current: count });

db.issues.createIndex({ id: 1 }, { unique: true });
db.issues.createIndex({ status: 1 });
db.issues.createIndex({ author: 1 });
db.issues.createIndex({ created: 1 });