const dateRegex = new RegExp('^\\d\\d\\d\\d-\\d\\d-\\d\\d');

function jsonDateReviver(key, value) {
  if (dateRegex.test(value)) return new Date(value);
  return value;
}

class IssueFilter extends React.Component {
  render() {
    return (
      <div>Write your Reviews for the Books and They Will be Saved and Stored in The Database.</div>
    );
  }
}

function IssueRow(props) {
  const issue = props.issue;
  return (
    <tr>
      <td>{issue.id}</td>
      <td>{issue.author}</td>
      <td>{issue.created.toDateString()}</td>
      <td>{issue.title}</td>
      <td>{issue.published}</td>
      <td>{issue.review}</td>
      <td>{issue.genre}</td>
      <td>{issue.rating}</td>
      <td>{issue.username}</td>
    </tr>
  );
}

function IssueTable(props) {
  const issueRows = props.issues.map(issue =>
    <IssueRow key={issue.id} issue={issue} />
  );

  return (
    <table className="bordered-table">
      <thead>
        <tr>
          <th>ID❌</th>
          <th>Author✍</th>
          <th>Created🕯️</th>
          <th>Title📕</th>
          <th>Published🎂</th>
          <th>Review📝</th>
          <th>Genre📖</th>
          <th>Rating⭐</th>
          <th>Username™</th>
        </tr>
      </thead>
      <tbody>
        {issueRows}
      </tbody>
    </table>
  );
}

class IssueAdd extends React.Component {
  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(e) {
    e.preventDefault();
    const form = document.forms.issueAdd;
    const issue = {
      author: form.author.value, 
      title: form.title.value,
      review: form.review.value,
      genre: form.genre.value,
      published: parseInt(form.published.value),
      rating: parseInt(form.rating.value),
      username: form.username.value,
    }
    this.props.createIssue(issue);
    form.author.value = ""; 
    form.title.value = "";
    form.review.value="";
    form.genre.value="";
    form.published.value = "";
    form.rating.value = "";
    form.username.value = "";
  }

  render() {
    return (
      <form name="issueAdd" onSubmit={this.handleSubmit}>
        <p>Write the Author for the Story</p>
        <input type="text" name="author" placeholder="Author" />
        <p>Write the Title of the Book</p>
        <input type="text" name="title" placeholder="Title" />
        <p>Review The Book</p>
        <textarea type="text" name="review" rows="4" cols="50">Enter a good review.</textarea>
        <p>Select a Genre For the Story</p>
        <select type="text" name="genre" placeholder="Genre">
          <option value="Action">Action</option>
          <option value="Adventure">Adventure</option>
          <option value="Comedy">Comedy</option>
          <option value="Contemporary">Contemporary</option>
          <option value="Comedy">Comedy</option>
          <option value="Drama">Drama</option>
          <option value="Fantasy">Fantasy</option>
          <option value="Historical">Historical</option>
          <option value="Horror">Horror</option>
          <option value="Mystery">Mystery</option>
          <option value="Psychological">Psychological</option>
          <option value="Romance">Romance</option>
          <option value="Satire">Satire</option>
          <option value="Sci-fi">Sci-Fi</option>
          <option value="Short Story">Short Story</option>
          <option value="Tragedy">Tragedy</option>
        </select>
        <p>When was this book published?</p>
        <input type="int" name="published" placeholder="Published" />
        <p>Rate the Story from 1 to 5 Stars</p>
        <input type="int" name="rating" placeholder="Rating" />
        <p>Write Your Username for the Review</p>
        <input type="string" name="username" placeholder="Username" />
        <button>Add</button>
      </form>
    );
  }
}

async function graphQLFetch(query, variables = {}) {
  try {
    const response = await fetch('/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json'},
      body: JSON.stringify({ query, variables })
    });
    const body = await response.text();
    const result = JSON.parse(body, jsonDateReviver);

    if (result.errors) {
      const error = result.errors[0];
      if (error.extensions.code == 'BAD_USER_INPUT') {
        const details = error.extensions.exception.errors.join('\n ');
        alert(`${error.message}:\n ${details}`);
      } else {
        alert(`${error.extensions.code}: ${error.message}`);
      }
    }
    return result.data;
  } catch (e) {
    alert(`Error in sending data to server: ${e.message}`);
  }
}

class IssueList extends React.Component {
  constructor() {
    super();
    this.state = { issues: [] };
    this.createIssue = this.createIssue.bind(this);
  }

  componentDidMount() {
    this.loadData();
  }

  async loadData() {
    const query = `query {
      issueList {
        id author created title
        review genre published rating username
      }
    }`;

    const data = await graphQLFetch(query);
    if (data) {
      this.setState({ issues: data.issueList });
    }
  }

  async createIssue(issue) {
    const query = `mutation issueAdd($issue: IssueInputs!) {
      issueAdd(issue: $issue) {
        id
      }
    }`;

    const data = await graphQLFetch(query, { issue });
    if (data) {
      this.loadData();
    }
  }

  render() {
    return (
      <React.Fragment>
        <h1>Book Review and Marker</h1>
        <IssueFilter />
        <hr />
        <IssueTable issues={this.state.issues} />
        <hr />
        <IssueAdd createIssue={this.createIssue} />
      </React.Fragment>
    );
  }
}

const element = <IssueList />;

ReactDOM.render(element, document.getElementById('contents'));